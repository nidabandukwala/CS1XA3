from django.apps import AppConfig


class StartConfig(AppConfig):
    name = 'start'
