from django.apps import AppConfig


class DoneConfig(AppConfig):
    name = 'done'
