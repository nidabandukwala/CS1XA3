$(document).ready(function(){
    $("button").click(function(){
        $("img").hide();
    });
});
